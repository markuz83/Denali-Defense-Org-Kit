<?xml version="1.0" encoding="UTF-8"?>
<Workflow xmlns="http://soap.sforce.com/2006/04/metadata">
    <fieldUpdates>
        <fullName>Margin_Approval_Approved</fullName>
        <description>Margin Exception approval: final approval.</description>
        <field>Margin_Approval_Status__c</field>
        <literalValue>Approved</literalValue>
        <name>Margin Approval: Approved</name>
        <notifyAssignee>false</notifyAssignee>
        <operation>Literal</operation>
        <protected>false</protected>
        <reevaluateOnChange>false</reevaluateOnChange>
    </fieldUpdates>
    <fieldUpdates>
        <fullName>Margin_Approval_Clear</fullName>
        <description>Margin Exception approval: recalled.</description>
        <field>Margin_Approval_Status__c</field>
        <name>Margin Approval: Clear</name>
        <notifyAssignee>false</notifyAssignee>
        <operation>Null</operation>
        <protected>false</protected>
        <reevaluateOnChange>false</reevaluateOnChange>
    </fieldUpdates>
    <fieldUpdates>
        <fullName>Margin_Approval_Pending</fullName>
        <description>Margin Exception approval: submitted.</description>
        <field>Margin_Approval_Status__c</field>
        <literalValue>Pending</literalValue>
        <name>Margin Approval: Pending</name>
        <notifyAssignee>false</notifyAssignee>
        <operation>Literal</operation>
        <protected>false</protected>
        <reevaluateOnChange>false</reevaluateOnChange>
    </fieldUpdates>
    <fieldUpdates>
        <fullName>Margin_Approval_Rejected</fullName>
        <description>Margin Exception approval: final rejection.</description>
        <field>Margin_Approval_Status__c</field>
        <literalValue>Rejected</literalValue>
        <name>Margin Approval: Rejected</name>
        <notifyAssignee>false</notifyAssignee>
        <operation>Literal</operation>
        <protected>false</protected>
        <reevaluateOnChange>false</reevaluateOnChange>
    </fieldUpdates>
</Workflow>
